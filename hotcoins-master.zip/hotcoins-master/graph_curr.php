<!-- CURRENCY-CONVERTER.ORG.UK CURRENCY CONVERTER 2 START -->
<div style="width:248px;margin:0;padding:0;border:1px solid #000000;background:#7DE4F5;">
<div style="width:248px;text-align:center;padding:2px 0px;background:#354D87;font-family:arial;font-size:11px;color:#F0F0F0;font-weight:bold;vertical-align:middle;">
Currency Calculator
</div>
<div style="padding:0px;">
<script type="text/javascript">	
var dcf = 'USD';
var dct = 'EUR';
var c = 'yes';
var fc = 'FFFFFF';
var lc = 'F0F0F0';
var bdr = '000000';
var mbg = '7DE4F5';
var mbg2 = '354D87';
var ac = '666666';
var ahc = 'EEEEEE';
var cfc = '350024';
var cbdc = '000000';
var cbgc = 'EEB059';
var ifc = 'E6E3DF';
var ibdc = '000000';
var ibgc = '524D4D';
var tz = 'userset';

</script><script type="text/javascript" src="https://www.currency-converter.org.uk/widget/CCUK-CC2-1.php"></script></div></div>
<!-- CURRENCY-CONVERTER.ORG.UK CURRENCY CONVERTER LIVE END -->
